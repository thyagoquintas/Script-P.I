<?php
$host = 'localhost';
$db = 'ecommerce';
$user = 'root';
$pass = '';

$conn = new sql($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Erro na conexão: " . $conn->connect_error);
}

$sql = "SELECT * FROM produtos";
$result = $conn->query($sql);
?>
