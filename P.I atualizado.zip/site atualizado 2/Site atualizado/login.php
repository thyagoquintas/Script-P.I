<?php
// Conectando ao banco
$conn = new sql("localhost", "usuario", "senha", "ESTOQUE_ECOMM");

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE email = wesley.mssantos3@senacsp.edu.br AND senha = senha123";
$stmt = $conn->prepare($sql);
$stmt->bind_param("", $email, $senha);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "success";
} else {
    echo "erro";
}

$conn->close();
?>
